package service;

import dao.WalletDao;
import dao.WalletDaoImpl;
import dto.Wallet;
import exception.WalletException;

import java.util.Objects;

public class WalletServiceImpl implements WalletService {

	private WalletDao walletRepository = new WalletDaoImpl();
	
	
	public Wallet registerWallet(Wallet newWallet) throws WalletException {
		
		return this.walletRepository.addWallet(newWallet);
		
	}

	public Boolean login(Integer walletId, String password) throws WalletException {
		// TODO Auto-generated method stub
		try {
			Wallet wal = walletRepository.getWalletById(walletId);
			if (Objects.equals(wal.getPassword(), password)) {
				return true;
			} else {

				throw new WalletException(super.toString());


			}
		} catch (WalletException ae) {
			throw new WalletException("Password-NotMatch");

		}
	}

	public Double addFundsToWallet(Integer walletId, Double amount) throws WalletException {
		// TODO Auto-generated method stub
		Double currentbal,addbal,finalAmt;

		Wallet wal=walletRepository.getWalletById(walletId);
		currentbal=wal.getBalance();
		addbal=currentbal+amount;
		wal.setBalance(addbal);
		this.walletRepository.updateWallet(wal);
		Wallet updatedWal =walletRepository.getWalletById(walletId);
		finalAmt=updatedWal.getBalance();



		return finalAmt;
	}

	public Double showWalletBalance(Integer walletId) throws WalletException {
		// TODO Auto-generated method stub
		Wallet wal=walletRepository.getWalletById(walletId);
		Double balance;
		balance=wal.getBalance();

		return balance;
	}

	public Boolean fundTransfer(Integer fromId, Integer toId, Double amount) throws WalletException {

		boolean sc = true;
		Double frombal, tobal;
		Wallet fromAccount= walletRepository.getWalletById(fromId);
		Wallet toAccount =walletRepository.getWalletById(toId);
		frombal=fromAccount.getBalance();
		if(frombal>=amount) {

			frombal =- amount;
			fromAccount.setBalance(frombal);
			this.walletRepository.updateWallet(fromAccount);
			tobal = amount + toAccount.getBalance();
			toAccount.setBalance(tobal);


			System.out.println(this.walletRepository.updateWallet(toAccount));
			return sc;
		}else {
			throw new WalletException("Insufficient Balance");
		}
	}

	public Wallet unRegisterWallet(Integer walletId, String password) throws WalletException {
		// TODO Auto-generated method stub
		try {
			Wallet wal = walletRepository.getWalletById(walletId);
			if (Objects.equals(wal.getPassword(), password)) {
				this.walletRepository.deleteWalletById(walletId);

			} else {
				throw new WalletException(super.toString());
			}
		}catch (WalletException ae){
			throw new WalletException("Password-NotMatch");

		}

		return null;
	}

}
